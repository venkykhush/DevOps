package com.lti.service;

import java.util.List;

import com.lti.entity.Account;
import com.lti.entity.AccountDao;
import com.lti.entity.Album;
import com.lti.entity.GenericDao;
import com.lti.entity.MusicDao;
import com.lti.entity.Song;

public class MusicService {
	
		public void addAlbum(Album album) {
		MusicDao dao= new MusicDao();
		dao.save(album);
		
	}
		
		public void addSong(int albumid,Song song)  {
			
			GenericDao dao = new GenericDao();
			Song s = new Song();
			Album al = (Album) dao.fetchByPK(Album.class, albumid);
			s.setTitle(song.getTitle());
			s.setDuration(song.getDuration());
			s.setSinger(song.getSinger());
			s.setAlbum(al);
			
			dao.save(s);
		}

		public List<Song> fetchSongBySinger(String singer) {
			MusicDao dao =new MusicDao();
			List<Song> songs=dao.fetchSongBySinger(singer);
			
			return songs;
			
		}
}
