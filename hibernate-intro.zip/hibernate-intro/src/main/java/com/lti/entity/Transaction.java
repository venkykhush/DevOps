package com.lti.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Tx_TBL")
public class Transaction{

	@Id
	@GeneratedValue
	@Column(name = "tx_no")
	private long transactionNo;
	
	@Column(name="TX_DATE")
	private Date date;
	
	@Column(name="TX_TYPE")
	private String type;
	private double amount;
	
	@ManyToOne
	@JoinColumn(name = "acc_no")
	private Account account;

	public long getTransactionNo() {
		return transactionNo;
	}

	public void setTransactionNo(long transactionNo) {
		this.transactionNo = transactionNo;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public Account getAccount() {
		return account;
	}

	public void setAccount(Account account) {
		this.account = account;
	}

	@Override
	public String toString() {
		return "Transaction [transactionNo=" + transactionNo + ", date=" + date + ", type=" + type + ", amount="
				+ amount + ", account=" + account + "]";
	}
	
	
}
