package com.lti.test;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.lti.component.CarPart;
import com.lti.component.CarPartsInventory;

public class CarPartTest {

	@Test
	public void testAddCarPart() {
		
		ApplicationContext context = new ClassPathXmlApplicationContext("spring-config.xml");
		
		CarPartsInventory cpi = (CarPartsInventory) context.getBean("carPartsImpl2");
		
		CarPart c = new CarPart();
		c.setPartNo(171);
		c.setPartName("head lights");
		c.setCarModel("swift dezire");
		c.setQuantity(100);
		
		cpi.addNewPart(c);
	}

	@Test
	public void carPartTest() {
		ApplicationContext context = new ClassPathXmlApplicationContext("spring-config.xml");
		
		CarPartsInventory cpi = (CarPartsInventory) context.getBean("carPartsImpl4");
		List<CarPart> list= cpi.getAvailableParts();
		
		
		for(CarPart carPart :list) {
			System.out.println(carPart.getCarModel());
			System.out.println(carPart.getPartName());
			System.out.println();
		}
	}
}
