package com.lti.entity;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class GenericDao {
	

	public void save(Object obj) {
		
		System.out.println(obj.getClass());
		
		EntityManagerFactory emf = null;
		EntityManager em = null;
		
		try {
			
		
		emf = Persistence.createEntityManagerFactory("oracle-pu");
		em = emf.createEntityManager();
		
		//find method generates select query
		
		EntityTransaction tx=em.getTransaction();
		tx.begin();
		
		em.merge(obj);
		tx.commit();
		
		}
			
		finally {
			
			em.close();
			emf.close();
		}
	}
	
	public Object fetchByPK(Class classname , Object id) {
		
		EntityManagerFactory emf = null;
		EntityManager em = null;
		
		try {
			
		
		emf = Persistence.createEntityManagerFactory("oracle-pu");
		em = emf.createEntityManager();
		
		//find method generates select query
		Object obj = em.find(classname, id);
		
		return obj;
		
		}
		finally {
			em.close();
			emf.close();
		}
	}
	
	public <E> List<E> databasefetchAllRecords(Class<E> clazz) {	//we can use ? in place of Object
		
		EntityManagerFactory emf = null;
		EntityManager em = null;
		
		try {
			
		emf = Persistence.createEntityManagerFactory("oracle-pu");
		em= emf.createEntityManager();
		
		//introducing JP-QL
		Query q = em.createQuery("select obj from "+ clazz.getName() + " as obj");
		
		List<E> list = q.getResultList();
		
		return list;
		
		}
		
		finally {
			
		em.close();
		emf.close();
		
		}

		
	}
}
