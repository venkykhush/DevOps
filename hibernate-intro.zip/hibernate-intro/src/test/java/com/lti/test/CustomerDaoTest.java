package com.lti.test;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;

import com.lti.entity.Customer;
import com.lti.entity.CustomerDao;

public class CustomerDaoTest {

	@Test
	public void testAdd() {
		
	Customer c=new Customer();
	c.setName("Shaik");
	c.setEmail("rafiq2k13@gmail.com");
	c.setCity("AndhraPradesh");
	
	Customer d=new Customer();
	d.setName("Stefan");
	d.setEmail("Stefan@vampirediaries.com");
	d.setCity("Mystic falls");
	
	
	
   // c.setDateOfBirth(1-12-1998);	
	
	CustomerDao dao=new CustomerDao();
		
		dao.insertOrUpdate(c);
	}
	
	
	
	@Test
	public void testFetch() {
		CustomerDao dao=new CustomerDao();
		Customer cust=dao.databaseIlVangudhal(28); //please check the id in db
		
		System.out.println(cust.getName());
		System.out.println(cust.getEmail());
		System.out.println(cust.getDateOfBirth());
		System.out.println(cust.getCity());
	}

	
	@Test
	public void testUpdate() {
		
		CustomerDao dao=new CustomerDao();
		
		Customer cust=dao.databaseIlVangudhal(1);
		
		cust.setCity("hyderabad");
		
		dao.insertOrUpdate(cust);
	
}
	@Test
	public void testFetchAll() {
		CustomerDao dao=new CustomerDao();
		List<Customer> list=dao.databasefetchall(); //please check the id in db
		
		for(Customer cust : list) {
		System.out.println(cust.getName());
		System.out.println(cust.getEmail());
		System.out.println(cust.getDateOfBirth());
		System.out.println(cust.getCity());
		}
}
	@Test
	public void testEmail() {
		CustomerDao dao=new CustomerDao();
		Customer cust= dao.databaseFetchByEmail("cullens@twilight.com");//please check the id in db
		System.out.println(cust.getName());
	}
}
