package com.lti.component;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Component;

@Component("orderDataImpl1")
public class OrderDataImpl1 implements OrderData {
	
	@PersistenceContext
	private EntityManager entityManager;
	
	@Transactional
	public void addNewOrder(KFC kfc) {
		entityManager.persist(kfc);
		
	
		
	}

	public List<KFC> getAvailableOrders() {
		
		return entityManager.createQuery("select k from KFC k" ).getResultList();
	}
	

}
