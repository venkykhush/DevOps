package com.lti.entity;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;

import com.lti.service.MusicService;

public class MusicTest {

	@Test
	public void testAddAlbum() {
		
	  MusicService muServ = new MusicService();
	  Album album = new Album();
	  album.setId(111);
	  album.setName("RabNeBanadiJodi");
	  album.setCopyright("Approved");
	  album.setYear(2008);
	  muServ.addAlbum(album);
	  }
	
	@Test
	public void testAddSong() {
		
	  MusicService muServ = new MusicService();
	  Song song = new Song();
	  song.setTitle("rab ne banadi jodi");
	  song.setSinger("shreya ghoshal");
	  song.setDuration(3.05);
	  muServ.addSong(161, song);
	  }
	
	@Test
	public void testFetchSongBySinger() {
		MusicService muServ = new MusicService();
		
		List<Song> songs= muServ.fetchSongBySinger("shreya ghoshal");
		
		for(Song song : songs) {
			System.out.println(song);
		}
	}
}

