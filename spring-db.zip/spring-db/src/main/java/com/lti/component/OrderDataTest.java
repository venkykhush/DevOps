package com.lti.component;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class OrderDataTest {

	@Test
	public void testAddOrder() {
		
		ApplicationContext context = new ClassPathXmlApplicationContext("spring-config.xml");
		
		OrderData od= (OrderData) context.getBean("orderDataImpl1");
		
		KFC kfc= new KFC();
		kfc.setItemName("veg strips");
		kfc.setItemType("veg");
		kfc.setQuantity(15);
		od.addNewOrder(kfc);
		
	}
	
	@Test
	public void testFetchOrder() {
		
	ApplicationContext context = new ClassPathXmlApplicationContext("spring-config.xml");
	
	OrderData od= (OrderData) context.getBean("orderDataImpl1");
	List<KFC> list=od.getAvailableOrders();
	
	for(KFC kfc : list) {
		System.out.println(kfc.getItemName());
		System.out.println(kfc.getQuantity());
		System.out.println(kfc.getItemType());
	}
	}
}
