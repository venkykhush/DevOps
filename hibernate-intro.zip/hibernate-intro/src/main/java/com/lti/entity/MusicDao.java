package com.lti.entity;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class MusicDao extends GenericDao {
	
public List<Album> fetchAlbumsById(int albumId){
		
		EntityManagerFactory emf=null;
		EntityManager em = null;
		
		try{
			
			emf=Persistence.createEntityManagerFactory("oracle-pu");
	
			em=emf.createEntityManager();
			
			String ql= "select a from Album a where a.album.albumid = :al ";
			
			
			Query q= em.createQuery(ql);
			q.setParameter("al",albumId);
			List<Album> list=q.getResultList();
					return list;
		}
		
		finally {	
		
			em.close();
			emf.close();
		}
		
	}
	
public List<Song> fetchSongBySinger(String singer){
	
	EntityManagerFactory emf=null;
	EntityManager em = null;
	
	try{
		
		emf=Persistence.createEntityManagerFactory("oracle-pu");

		em=emf.createEntityManager();
		
		String ql= "select s from Song s where singer= :sin";
		
		
		Query q= em.createQuery(ql);
		q.setParameter("sin",singer);
		List<Song> list=q.getResultList();
		return list;
	}
	
	finally {	
	
		em.close();
		emf.close();
		}
	}
}
