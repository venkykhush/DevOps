package com.lti.component;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;



@Component("carPartsImpl2")
public class CarPartsInventoryImpl2 implements CarPartsInventory {

	@Autowired
	@Qualifier("dataSource1")
	private DataSource dataSource;
	
	public void addNewPart(CarPart carpart) {
		
		Connection conn=null;	
		PreparedStatement stmt=null;	
		
		try {
			
			conn=dataSource.getConnection();
			//conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","hr","hr");
			
			String sql="insert into CarPart values(?,?,?,?)";
					
			stmt=conn.prepareStatement(sql);
			
			stmt.setInt(1, carpart.getPartNo());
			stmt.setString(2, carpart.getPartName());
			stmt.setString(3, carpart.getCarModel());
			stmt.setInt(4, carpart.getQuantity());
			stmt.executeUpdate();
		
		}
		
		/*catch(ClassNotFoundException e){
			
			e.printStackTrace();
		}*/
		
		catch(SQLException e) {
			
			e.printStackTrace();
		}
		
		finally {
			try {
				conn.close(); 
				} 
			catch (Exception e) {  }
		}//End of Finally Block		
}

	public List<CarPart> getAvailableParts() {
		
		
		return null;
	}
}
