package com.lti.entity;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class CustomerDao {
 
	public void databaseIlAddSeiyavum(Customer customer) {
		
		EntityManagerFactory emf=null;
		EntityManager em = null;
		
		try{
			
		
			emf=Persistence.createEntityManagerFactory("oracle-pu");
	
			em=emf.createEntityManager();
			
			EntityTransaction tx=em.getTransaction();
			
			tx.begin();
	
		
			//now we can insert/delete/select/update whatever we want
		
			em.persist(customer);  //persist method generates insert query
			
			tx.commit();
		
		}
		
		finally {	
		
			em.close();
			emf.close();
		}

	}
	
	public Customer databaseIlVangudhal(int custId) {
		
		EntityManagerFactory emf = null;
		EntityManager em = null;
		
		try {
			
		
		emf = Persistence.createEntityManagerFactory("oracle-pu");
		em = emf.createEntityManager();
		
		//find method generates select query
		Customer c = em.find(Customer.class, custId);
		
		return c;
		
		}
		finally {
			em.close();
			emf.close();
		}
}
	
	public Customer insertOrUpdate(Customer customer) {
		
		EntityManagerFactory emf = null;
		EntityManager em = null;
		
		try {
			
		
		emf = Persistence.createEntityManagerFactory("oracle-pu");
		em = emf.createEntityManager();
		
		//find method generates select query
		
		EntityTransaction tx=em.getTransaction();
		tx.begin();
		
		em.merge(customer);
		tx.commit();
		
		return customer;
		}
			finally {
			
				em.close();
				emf.close();
		}
}
	public List<Customer> databasefetchall() {
		EntityManagerFactory emf = null;
		EntityManager em = null;
		
		try {
			
		emf = Persistence.createEntityManagerFactory("oracle-pu");
		em= emf.createEntityManager();
		
		//introducing JP-QL
		Query q = em.createQuery("select c from Customer c");
		List<Customer> list = q.getResultList();
		
		return list;
		
		}
		
		finally {
			
		em.close();
		emf.close();
		
		}

		
	}
	public Customer databaseFetchByEmail(String email) {
		
		EntityManagerFactory emf = null;
		EntityManager em = null; 
		
		try {
			
		emf= Persistence.createEntityManagerFactory("oracle-pu");
		em = emf.createEntityManager();
		
		//introducing JP-QL
		Query q = em.createQuery("select c from Customer c where c.email like :em");
		
		//Query q = em.createQuery("select c from Customer c whwre c.email like '%@?.%'");
		//q.setParameter(1, email);
		q.setParameter("em", "%" + email +"%");
		Customer cust = 
		(Customer) q.getSingleResult();
		return cust;
		
		}
		finally {
			
		em.close();
		emf.close();
		}

		
	}
	
}