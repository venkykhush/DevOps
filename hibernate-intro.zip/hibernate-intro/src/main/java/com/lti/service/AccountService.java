package com.lti.service;


import java.util.Date;
import java.util.List;

import com.lti.entity.Account;
import com.lti.entity.AccountDao;
import com.lti.entity.Transaction;

//classes which contain business logic are commonly referred to as Service classes
//people also use this naming convention in WebServices(SOAP/REST)

public class AccountService {
	
	public void openAccount(Account acc) {
		AccountDao dao = new AccountDao();
		dao.save(acc);
		//apart from this we might write/execute the code for sending email to the customer here
		
	}
	
	public void withdraw(long acno, double amount) {
		/*
		double withdraw;
		if(withdraw > 0.0) 
		if(withdraw > balance)
			System.out.println("Withdrawal amount exceeded account balance");
        else
            balance = balance - withdraw;
          */
			
		AccountDao dao  = new AccountDao();
		Transaction txn = new Transaction();
		Account acc =(Account)dao.fetchByPK(Account.class, acno);
		
		if(acc.getBalance()-amount>0)
			acc.setBalance(acc.getBalance()-amount);
		
		
		txn.setDate(new Date());
		txn.setType("withdraw");
		txn.setAmount(amount);
		txn.setAccount(acc);
		dao.save(txn);
		dao.save(acc);
		
		
		
	}
	
	public void deposit(long acno, double amount) {
		
		AccountDao dao = new AccountDao();
		Account acc =(Account)dao.fetchByPK(Account.class, acno);

		Transaction txn = new Transaction();
		acc.setBalance(acc.getBalance()+amount);
		
		txn.setDate(new Date());
		txn.setType("deposit");

		txn.setAmount(amount);
		txn.setAccount(acc);
		dao.save(txn);
		dao.save(acc);
		
		
		
	}
	
	public void transfer(long fromAcno, long toAcno,double amount) {
		
		AccountDao dao = new AccountDao();
		
		Account acc1 =(Account)dao.fetchByPK(Account.class, fromAcno);
		Account acc2 =(Account)dao.fetchByPK(Account.class, toAcno);
		acc1.setBalance(acc1.getBalance()-amount);
		acc2.setBalance(acc2.getBalance()+amount);
		dao.save(acc1);
		dao.save(acc2);
		
		Transaction tx1 = new Transaction();
		tx1.setDate(new Date());
		tx1.setType("moneyTransfer");
		tx1.setAmount(amount);
		tx1.setAccount(acc1);
		
		Transaction tx2 = new Transaction();
		tx2.setDate(new Date());
		tx2.setType("moneyReceived");
		tx2.setAmount(amount);
		tx2.setAccount(acc2);
		dao.save(tx1);
		dao.save(tx2);

	}
	
	public double checkBalance(long acno) {

		AccountDao dao = new AccountDao();
		Account acc =(Account)dao.fetchByPK(Account.class, acno);
		return acc.getBalance();
		
	}
	
	public List<Transaction> miniStatement(long acno) {
		AccountDao dao = new AccountDao();
		List<Transaction>list =dao.fetchMiniStatement(acno);
		return list;
		
	}
	public List<Account> fetchAccountsByBalance(double balance) {
		AccountDao dao = new AccountDao();
		List<Account>list =dao.fetchAccountsByBalance(balance);
		return list;

}
	public List<Account> fetchAccountsByActivity(String type, double amount) {
		AccountDao dao = new AccountDao();
		List<Account>list =dao.fetchAccountsByActivity(type,amount);
		return list;
}
}
