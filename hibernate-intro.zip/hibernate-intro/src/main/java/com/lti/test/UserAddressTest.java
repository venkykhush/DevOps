package com.lti.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.lti.entity.Address;
import com.lti.entity.GenericDao;
import com.lti.entity.User;


public class UserAddressTest {

	@Test
	public void addNewUser() {
		
		User user = new User();
		user.setName("VENKY");
		user.setEmail("venky@gmail.com");
		
		GenericDao dao = new GenericDao();
		dao.save(user);
		
	}
	
	@Test
	public void addAddressForAnExistingUser() {
		GenericDao dao = new GenericDao();
		User user = (User) dao.fetchByPK(User.class, 201);
		
		Address a = new Address();
		a.setCity("hyd");
		a.setState("telangana");
		a.setPincode(500002);
		a.setUser(user);
		dao.save(a);
		
		
	}
	
	@Test
	public void addUserAndAddressTogether() {

		User user = new User();
		user.setName("Subba");
		user.setEmail("subba@gmail.com");
		
		Address a = new Address();
		a.setCity("ongole");
		a.setState("Andhra Pradesh");
		a.setPincode(523002);
		a.setUser(user);
		
		user.setAddress(a);
		a.setUser(user);
		
		GenericDao dao = new GenericDao();
		dao.save(user);
		
	}
	
	@Test
	public void fetchUserAndAddressBoth() {
		GenericDao dao = new GenericDao();
		User user = (User) dao.fetchByPK(User.class, 201);
		System.out.println(user.getName());
		System.out.println(user.getEmail());
		
		Address a = user.getAddress();
		System.out.println(a.getCity());
		System.out.println(a.getState());
		System.out.println(a.getPincode());
		
		
	}

}
