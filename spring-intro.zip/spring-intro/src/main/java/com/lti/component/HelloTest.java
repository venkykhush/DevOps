package com.lti.component;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class HelloTest {
	
	public static void main(String[] args) {
		//loading Spring's IoC Container
		ApplicationContext context =
			    new ClassPathXmlApplicationContext("spring-config.xml");
		
		//accessing one of the bean
		HelloWorld hw = (HelloWorld) context.getBean("hw"); //bean id
		System.out.println(hw.sayHello("Venky"));
		
		
		Calculator c=(Calculator) context.getBean("cal");
		System.out.println(c.add(10,20));
		System.out.println(c.sub(10,20));
		
		CurrencyConvertor cc = (CurrencyConvertor) context.getBean("cc");
		System.out.println(cc.convertDollarsToRupees(50));
		
		Multiplication m =(Multiplication) context.getBean("mul");
		System.out.println(m.mul(25,25));
		
	}

}
 