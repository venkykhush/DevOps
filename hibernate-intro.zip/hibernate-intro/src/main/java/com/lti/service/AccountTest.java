package com.lti.service;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;

import com.lti.entity.Account;
import com.lti.entity.AccountDao;
import com.lti.entity.Transaction;

public class AccountTest {

	@Test
	public void testOpenAccount() {
		AccountService accServ = new AccountService();
		
		Account acc= new Account();
		acc.setName("Venky");
		acc.setType("Savings");
		acc.setBalance(6000);
		accServ.openAccount(acc);
		
		Account acc1 = new Account();
		acc1.setName("ram");
		acc1.setType("Savings");
		acc1.setBalance(9000);
		accServ.openAccount(acc1);
		
	}
	
	@Test
	public void testWithdraw() {
		AccountService accServ = new AccountService();
		Account acc =new Account();
		Transaction txn = new Transaction();
		txn.setAmount(1500);
		accServ.withdraw(101, txn.getAmount());
		
	}
	
	@Test
	public void testDeposit() {
		AccountService accServ = new AccountService();
		Account acc =new Account();
		Transaction txn = new Transaction();
		txn.setAmount(2000);
		accServ.deposit(142, txn.getAmount());
	
	
	}
	
	@Test
	public void testTransfer() {
		AccountService accServ = new AccountService();
		Account acc =new Account();
		Transaction txn = new Transaction();
		txn.setAmount(500);
		accServ.transfer(142,101,txn.getAmount());
		
	}
	
	@Test
	public void testTransfer1() {
		AccountService accServ = new AccountService();
		Account acc =new Account();
		Transaction txn = new Transaction();
		txn.setAmount(1500);
		accServ.transfer(141,101,txn.getAmount());
		
	
	}
	
	@Test
	public void testTransfer2() {
		AccountService accServ = new AccountService();
		Account acc =new Account();
		Transaction txn = new Transaction();
		txn.setAmount(1500);
		accServ.transfer(142,141,txn.getAmount());
	}
	
	@Test
	public void testTransfer3() {
		AccountService accServ = new AccountService();
		Account acc =new Account();
		Transaction txn = new Transaction();
		txn.setAmount(1500);
		accServ.transfer(101,141,txn.getAmount());
	}
	

	@Test
	public void testCheckBalance() {
		AccountService accServ = new AccountService();

		accServ.checkBalance(141);
		System.out.println(accServ);
	}
	
	@Test
	public void testMiniStatement() {
		AccountService accServ = new AccountService();
		List<Transaction>list = accServ.miniStatement(141);

		for(Transaction txn:list) {
			System.out.println(txn);
		}
	}
	
	@Test
	public void testFetchAccountsByBalance() {
		AccountDao dao = new AccountDao();
	List<Account>list=dao.fetchAccountsByBalance(1000);
		
		for(Account a :list) {
			System.out.println(a);
		}
	
	}
	@Test
	public void testFetchAccountsByActivity() {
		AccountDao dao = new AccountDao();
	List<Account>list=dao.fetchAccountsByActivity("moneyTransfer",100);
		
		for(Account a :list) {
			System.out.println(a);}
	}
}
