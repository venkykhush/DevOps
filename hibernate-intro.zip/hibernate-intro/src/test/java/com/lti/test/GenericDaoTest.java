package com.lti.test;

import java.util.Date;
import java.util.List;
//import java.util.Scanner;

import org.junit.Test;

import com.lti.entity.Customer;
import com.lti.entity.GenericDao;
import com.lti.entity.Order;
import com.lti.entity.Payment;

public class GenericDaoTest {

	//Scanner s= new Scanner(System.in);
	
	Payment payment = new Payment();
	Order order = new Order();

	GenericDao genericdao = new GenericDao();
	
	@Test
	public void addToDatabase1() {
		Order order1 =  new Order();
		Customer cus = (Customer)genericdao.fetchByPK(Customer.class,1);
		
		
		order1.setAmt(25000);
		order1.setOrderDate(new Date());
		order1.setCustomer(cus);
		
		genericdao.save(order);
	
		
	}
	@Test
	public void addToDatabase() {
		
		Payment pay = new Payment();
		
		pay.setAmount(18000);
		pay.setPaymentmode("UPI");
		pay.setPaymentstatus("Success");
		
		genericdao.save(pay);
		
	}
	
	@Test
	public void addToDatabase2() {
		
		Order or = (Order)genericdao.fetchByPK(Order.class, 86);
		
		Payment pa = (Payment)genericdao.fetchByPK(Payment.class, 90);
		
		or.setPayment(pa);
		
		genericdao.save(or);
	}
	
	
	@Test
	public void fetchAllFromGenericDao() {
		
		List<Order> orders =  genericdao.databasefetchAllRecords(Order.class);
		
		for (Order order : orders) {
			
			System.out.println(order.getId());
			System.out.println(order.getOrderDate());
			System.out.println(order.getAmt());
			System.out.println(order.getCustomer().getEmail());
			
		}
	}
	
	@Test
	public void fetchAllFromGenericDaoPay() {
		
		List<Payment> payments =  genericdao.databasefetchAllRecords(Payment.class);
		
		for (Payment payment : payments) {
			
			System.out.println(payment.getId());
			System.out.println(payment.getAmount());
			System.out.println(payment.getPaymentmode());
			System.out.println(payment.getPaymentstatus());
				
		}
		
		
		}
				
				
				
	}


