package com.lti.component;

import org.springframework.stereotype.Component;

@Component("mul")
public class Multiplication {
	
	public int mul(int x, int y) {
		return x*y;
	}

}
