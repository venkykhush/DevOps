package com.lti.component;

import java.util.List;

public interface OrderData {
	
	public void addNewOrder(KFC kfc) ;
		
	public List<KFC> getAvailableOrders();

}
