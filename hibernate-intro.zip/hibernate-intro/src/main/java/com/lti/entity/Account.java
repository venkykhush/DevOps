package com.lti.entity;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "Account_TBL")
public class Account {


	@Id
	@GeneratedValue
	@Column(name = "acc_no")
	private long accountnumber;
	
	@Column(name="AC_TYPE")
	private String type;
	
	private String name;
	private double balance;
	
	@OneToMany(mappedBy = "account")
	private Set<Transaction> transactions; //shows bidirectional relation //optional
	
	
	
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public Set<Transaction> getTransactions() {
		return transactions;
	}
	public void setTransactions(Set<Transaction> transactions) {
		this.transactions = transactions;
	}
	public long getAccountnumber() {
		return accountnumber;
	}
	public void setAccountnumber(long accountnumber) {
		this.accountnumber = accountnumber;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
		
		
	}
	@Override
	public String toString() {
		return "Account [accountnumber=" + accountnumber + ", type=" + type + ", name=" + name + ", balance=" + "balance" + "]";
	}
}
